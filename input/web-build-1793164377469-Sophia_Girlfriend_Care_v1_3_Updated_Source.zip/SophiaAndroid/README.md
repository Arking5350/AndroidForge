# Sophia AI — Android source project (v1.3 Advanced Phone Control + Call Announcements)

This is an updated Kotlin Android starter based on the earlier Jarvis 2070 project. It is source code, **not a built or tested APK**.

## Included in this revision
- Renamed UI/launcher to Sophia AI.
- Playful, caring Boss-style greetings based on time of day and return after absence (when face detection is running in the open app).
- Local conversation history stored in SharedPreferences and sent as short context to the online backend.
- Night-time reminder once per calendar day when the app is opened after 11 PM or before 5 AM.
- Optional incoming-call announcement service. When Android posts a recognizable call notification, Sophia speaks a short caller announcement. Enable it from the new in-app button and grant Notification Access manually. It does not auto-answer or reject calls.
- HTTPS endpoint field for online AI; PHP backend sample in `backend/chat.php` with a server-side API key.
- Android Security Settings and Accessibility Settings shortcuts.
- Explicit voice/text command router for mapped apps (Instagram, YouTube, WhatsApp, Facebook, Chrome, Gmail, Telegram, Spotify, Settings, Camera, Phone, Messages, Play Store).
- Safe call flow opens the dialer for a number; a contact-name call opens the Contacts picker rather than calling silently.
- SMS command opens a message draft for a phone number; the user reviews and sends it.
- App install opens Play Store search. App uninstall asks in-app confirmation and then uses Android's own uninstall confirmation screen.
- Optional `Sophia Phone Control` AccessibilityService supports explicit Back, Home, scroll and exact visible-text tap commands after the user manually enables it in Android Accessibility settings.
- Android Security Settings shortcut. Sophia cannot bypass the device lock or secretly approve sensitive dialogs.
- Camera frames are processed on-device by ML Kit while the Activity is visible; frames are not saved.

## Important: features not implemented yet
These are **not** present as working features in this starter: background/Home Screen camera detection, an always-on “Sophia” wake word, biometric speaker verification that reliably distinguishes the owner's voice, a natural neural voice engine, food/activity recognition, and automatic lock-screen unlocking. Voice-triggered answer/reject is also not implemented; incoming-call notifications are announcements only. Accessibility actions require the user to enable the service and only handle explicit navigation requests; this is not unrestricted control and some apps block accessibility automation. Android restricts background camera/microphone use, and secure unlocking must stay under Android's PIN/fingerprint/face authentication. A dedicated wake-word model/service, explicit permissions, foreground notification and device testing would be required; owner voice verification needs a real speaker-verification model and cannot be simulated by speech-to-text.

## Build from an Android phone (online builder route)
1. Download and extract this ZIP on your phone, or upload the ZIP directly if the builder accepts a project ZIP.
2. Open `https://professional-x.github.io/AndroidForge/` in your browser.
3. Upload/select the project ZIP, choose the Android/Gradle build flow, and use `debug` for a test build. Builder screens may change.
4. Wait for the workflow to finish. Download the generated APK only if the job reports success.
5. Install the APK; Android may ask you to allow installs from that browser/file manager. Only install a build you trust.
6. Open Sophia AI, grant camera/microphone permissions only if you want those features, and leave camera detection off when not needed.

Online build sites can access uploaded source and build logs. Do not upload API keys or secrets. If AndroidForge cannot build this project, use a trusted Android Gradle build service or Android Studio on a computer.

## Configure online AI
1. Deploy `backend/chat.php` to HTTPS hosting with PHP 8+, `curl`, and `mbstring`.
2. Configure server environment variables `AI_API_KEY`, `AI_BASE_URL`, and `AI_MODEL` (see `backend/README.md`).
3. In the app, enter the full HTTPS URL ending in `/chat.php`.
4. Send a test message. If it fails, check server logs and provider settings.

## Voice quality
The app uses Android's installed Text-to-Speech engine, so quality depends on the voice installed on the phone. Install a better Hindi/English voice under Android Settings → Text-to-speech output if available. The PHP backend returns text only; a natural neural voice service would need a separate TTS provider integration.

## Privacy and safety
- The app's local conversation history stays in app storage and is sent to the configured backend with the next message. Clear app data to erase it.
- Do not send private credentials, PINs, or financial secrets in chat.
- Face presence is not identity verification.
- The example PHP endpoint is a starter, not production hardened; add authentication, rate limits, monitoring and provider cost limits before exposing it publicly.

## Voice/text commands in v1.3

Examples: `open Instagram`, `open YouTube`, `call 9876543210`, `call Rahul` (opens Contacts picker), `message 9876543210 hello`, `install Telegram`, `uninstall Instagram`, `back`, `home`, `scroll down`, `tap Allow`. Commands are routed locally only when they are explicit user input; AI-generated text is never executed as a device command. The exact-text tap feature can click a visible UI element, so only issue taps you understand. Do not use it to approve payments, permissions, purchases, or security dialogs automatically.

## Incoming-call announcement setup

1. Open Sophia AI and tap **ENABLE INCOMING CALL ANNOUNCEMENTS**.
2. Android Notification Access settings will open. Manually allow **Sophia Incoming Call Announcements**.
3. The service only checks likely call notifications and speaks an announcement locally; notification formats differ by phone and calling app. It does not send notification content to the AI backend, and it cannot reliably detect every call.
4. Disable access any time from Android Settings → Notification access.

## Accessibility service setup

1. Install/open Sophia AI.
2. Tap **ENABLE ADVANCED PHONE CONTROL**.
3. In Android Settings → Accessibility → Installed/Downloaded apps, choose **Sophia Phone Control** and enable it yourself. Wording varies by Android vendor.
4. Return to Sophia and use explicit commands. Disable the service any time from the same Settings page.

Android may show a prominent warning for Accessibility access. This permission can observe and operate parts of the visible UI, so enable it only if you trust this source build. The service does not automatically confirm system dialogs.
