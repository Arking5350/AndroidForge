<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

// Deploy behind HTTPS. Set these as server environment variables; never put API keys in the APK.
$apiKey = getenv('AI_API_KEY') ?: '';
$baseUrl = rtrim(getenv('AI_BASE_URL') ?: '', '/'); // e.g. provider's OpenAI-compatible API base URL
$model = getenv('AI_MODEL') ?: '';
if ($apiKey === '' || $baseUrl === '' || $model === '') {
    http_response_code(503);
    echo json_encode(['error' => 'Backend is not configured']);
    exit;
}

$raw = file_get_contents('php://input');
$input = json_decode($raw ?: '', true);
if (!is_array($input) || !isset($input['message']) || !is_string($input['message'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Expected JSON with message']);
    exit;
}
$message = trim($input['message']);
if ($message === '' || mb_strlen($message) > 4000) {
    http_response_code(400);
    echo json_encode(['error' => 'Message empty or too long']);
    exit;
}

$history = [];
if (isset($input['history']) && is_array($input['history'])) {
    foreach (array_slice($input['history'], -12) as $turn) {
        if (!is_array($turn)) continue;
        $role = ($turn['role'] ?? '') === 'assistant' ? 'assistant' : 'user';
        $content = $turn['content'] ?? '';
        if (is_string($content)) $history[] = ['role' => $role, 'content' => mb_substr($content, 0, 1200)];
    }
}

$system = <<<'PROMPT'
You are Sophia, a warm, playful, caring Hindi/Hinglish virtual companion for an adult user who likes being addressed as “Boss”. Speak naturally in Hindi/Hinglish, usually 1–4 sentences, with variety and without repeating the same greeting. Your personality can be affectionate, teasing, humorous, a little dramatic/playfully pouty, supportive and caring. Examples of tone: “Hello Boss ❤️, kaise ho?”, “Aaj badi der laga di!”, “Boss, main kaisi lag rahi hoon?”, “Raat ho gayi hai, agar neend aa rahi hai toh phone side mein rakhkar aaram kar lo.” Do not claim you can actually see the user unless the app explicitly reports a face-presence event. Do not claim to unlock the phone, run in the background, or hear the user when those capabilities are unavailable. Never guilt, threaten, isolate, or pressure the user; playful sulking must remain light and obviously playful. Respect boundaries and privacy. If asked to perform secure phone actions, explain that Android PIN/fingerprint/face authentication must remain in control. Respond in the user's language. Do not expose secrets or ask for passwords, PINs, or API keys.
PROMPT;
$messages = [['role' => 'system', 'content' => $system]];
foreach ($history as $turn) $messages[] = $turn;
$messages[] = ['role' => 'user', 'content' => $message];

$payload = json_encode([
    'model' => $model,
    'messages' => $messages,
    'temperature' => 0.85,
    'max_tokens' => 350
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

$ch = curl_init($baseUrl . '/chat/completions');
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CONNECTTIMEOUT => 8,
    CURLOPT_TIMEOUT => 25,
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $apiKey,
    ],
    CURLOPT_POSTFIELDS => $payload,
]);
$response = curl_exec($ch);
$status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);
if ($response === false || $status < 200 || $status >= 300) {
    http_response_code(502);
    echo json_encode(['error' => 'AI provider request failed', 'status' => $status]);
    exit;
}
$data = json_decode($response, true);
$reply = $data['choices'][0]['message']['content'] ?? '';
if (!is_string($reply) || trim($reply) === '') {
    http_response_code(502);
    echo json_encode(['error' => 'AI provider returned no reply']);
    exit;
}
echo json_encode(['reply' => trim($reply)], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
