# Sophia AI HTTPS backend (PHP)

This example powers the Online Smart conversation. It is a generic OpenAI-compatible chat-completions adapter; your provider must support `POST {AI_BASE_URL}/chat/completions`.

## Requirements
- PHP 8+ with `curl` and `mbstring` extensions
- HTTPS hosting
- An API key and model from an AI provider that supports the compatible endpoint

## Configure server environment variables
- `AI_API_KEY` — provider key (server only)
- `AI_BASE_URL` — provider API base URL, without trailing slash
- `AI_MODEL` — model identifier

Upload `chat.php` to an HTTPS host. Set the app's AI backend field to the full URL ending in `/chat.php`. Do not paste API keys into the Android app or commit them to GitHub. Add provider-appropriate rate limiting/authentication before public deployment; this starter endpoint does not yet include user authentication or production abuse protection.

The app sends the current message, a random local client ID, and up to 12 recent conversation turns. The client ID is not authentication. Do not use it to authorize sensitive actions.
