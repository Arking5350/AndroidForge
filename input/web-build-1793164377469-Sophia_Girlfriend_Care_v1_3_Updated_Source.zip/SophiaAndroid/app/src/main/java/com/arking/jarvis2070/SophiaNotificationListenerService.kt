package com.arking.jarvis2070

import android.app.Notification
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * Optional incoming-call announcement helper.
 * It only inspects notifications that Android labels as CALL (or recognized phone-call
 * notifications from common dialer/WhatsApp packages). It does not read general messages,
 * forward notification text to the AI backend, or answer/reject calls automatically.
 */
class SophiaNotificationListenerService : NotificationListenerService(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var lastAnnouncementKey = ""
    private var lastAnnouncementAt = 0L

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true
            tts?.language = Locale("hi", "IN")
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        val n = sbn.notification ?: return
        if (sbn.packageName == packageName) return
        val extras = n.extras ?: return
        val categoryCall = n.category == Notification.CATEGORY_CALL
        val pkg = sbn.packageName.lowercase(Locale.ROOT)
        val likelyCallApp = pkg.contains("dialer") || pkg.contains("incall") ||
            pkg.contains("telecom") || pkg == "com.whatsapp" || pkg == "com.whatsapp.w4b"
        if (!categoryCall && !likelyCallApp) return

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        val combined = "$title $text".lowercase(Locale.ROOT)
        val callWords = listOf("incoming call", "calling", "ringing", "call from", "voice call", "video call", "incoming")
        if (!categoryCall && callWords.none { combined.contains(it) }) return

        val caller = when {
            title.isNotBlank() && !title.equals("Phone", true) && !title.equals("WhatsApp", true) -> title
            text.isNotBlank() -> text
            else -> "kisi ka"
        }.take(80)
        val key = "${sbn.packageName}:$caller"
        val now = System.currentTimeMillis()
        if (key == lastAnnouncementKey && now - lastAnnouncementAt < 25_000L) return
        lastAnnouncementKey = key
        lastAnnouncementAt = now
        val phrase = if (caller == "kisi ka") "Boss, kisi ka call aa raha hai. Aap pick karna chahte hain ya cut?" else
            "Boss, $caller ka call aa raha hai. Aap pick karna chahte hain ya cut?"
        if (ttsReady) tts?.speak(phrase, TextToSpeech.QUEUE_FLUSH, null, "sophia-incoming-call")
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) { }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    companion object {
        fun isNotificationAccessEnabled(context: Context): Boolean {
            val enabled = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners") ?: return false
            return enabled.split(":").any { ComponentName.unflattenFromString(it)?.packageName == context.packageName }
        }

        fun openNotificationAccessSettings(context: Context) {
            context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
}
