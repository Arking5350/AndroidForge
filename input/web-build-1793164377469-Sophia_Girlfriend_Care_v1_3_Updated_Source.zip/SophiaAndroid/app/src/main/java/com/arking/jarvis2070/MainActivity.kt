package com.arking.jarvis2070

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.*
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import org.json.JSONObject
import org.json.JSONArray
import java.util.UUID
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.cos
import kotlin.math.sin

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var avatar: HoloAvatarView
    private lateinit var previewView: PreviewView
    private lateinit var endpointInput: EditText
    private lateinit var cameraToggle: Switch
    private lateinit var autoGreetingToggle: Switch
    private lateinit var tts: TextToSpeech
    private var speechRecognizer: SpeechRecognizer? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var cameraExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private var cameraEnabled = false
    private var facePresent = false
    private var lastGreetingAt = 0L
    private var lastSeenAt = 0L
    private var ttsReady = false
    private var lastHeard = ""
    private val cooldownMs = 90_000L
    private val memoryPrefs by lazy { getSharedPreferences("sophia_memory", MODE_PRIVATE) }
    private val memory = mutableListOf<Pair<String, String>>()
    private val clientId by lazy { memoryPrefs.getString("client_id", null) ?: UUID.randomUUID().toString().also { memoryPrefs.edit().putString("client_id", it).apply() } }
    private val requestPermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val cameraGranted = result[Manifest.permission.CAMERA] == true
        if (cameraGranted && cameraToggle.isChecked) startCamera()
        else if (!cameraGranted) setStatus("Camera permission nahi mili — camera detection band hai.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        loadMemory()
        buildUi()
        maybeNightReminder()
        if (!allPermissionsGranted()) requestPermissions.launch(
            arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        )
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(16))
            setBackgroundColor(Color.rgb(5, 9, 20))
        }
        val scroller = ScrollView(this)
        scroller.addView(root)
        setContentView(scroller)

        val heading = TextView(this).apply {
            text = "S O P H I A   A I"
            textSize = 24f
            setTextColor(Color.rgb(90, 237, 255))
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
            setPadding(0, dp(10), 0, dp(4))
        }
        root.addView(heading, match())
        val subtitle = TextView(this).apply {
            text = "YOUR PERSONAL AI COMPANION  •  ONLINE MODE"
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(125, 153, 185))
        }
        root.addView(subtitle, match())

        avatar = HoloAvatarView(this)
        root.addView(avatar, LinearLayout.LayoutParams(-1, dp(250)).apply {
            topMargin = dp(8); bottomMargin = dp(8)
        })

        status = TextView(this).apply {
            text = "SYSTEM STANDBY · CAMERA OFF"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(75, 232, 255))
            setPadding(0, dp(6), 0, dp(10))
        }
        root.addView(status, match())

        previewView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            visibility = View.GONE
        }
        root.addView(previewView, LinearLayout.LayoutParams(-1, dp(180)).apply {
            bottomMargin = dp(8)
        })

        cameraToggle = Switch(this).apply {
            text = "Camera presence detection (visible while active)"
            setTextColor(Color.WHITE)
            textSize = 13f
            isChecked = false
            setOnCheckedChangeListener { _, checked ->
                if (checked) {
                    if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA)
                        == PackageManager.PERMISSION_GRANTED) startCamera()
                    else requestPermissions.launch(arrayOf(Manifest.permission.CAMERA))
                } else stopCamera()
            }
        }
        root.addView(cameraToggle, match())

        autoGreetingToggle = Switch(this).apply {
            text = "Greet when a face appears / returns"
            setTextColor(Color.WHITE)
            textSize = 13f
            isChecked = true
        }
        root.addView(autoGreetingToggle, match())

        transcript = TextView(this).apply {
            text = "Sophia: Hello Boss ❤️ Main ready hoon. Camera on karoge toh main app khuli hone par face presence detect kar sakti hoon."
            textSize = 15f
            setTextColor(Color.rgb(225, 240, 255))
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.rgb(12, 22, 40))
        }
        root.addView(transcript, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(10); bottomMargin = dp(10)
        })

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val talkButton = actionButton("TALK TO SOPHIA") { listen() }
        val stopButton = actionButton("STOP VOICE") { speechRecognizer?.cancel(); tts.stop(); avatar.speaking = false }
        row.addView(talkButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(6) })
        row.addView(stopButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply { leftMargin = dp(6) })
        root.addView(row, match())

        val prompt = EditText(this).apply {
            hint = "Type a message…"
            setHintTextColor(Color.rgb(110, 132, 160))
            setTextColor(Color.WHITE)
            textSize = 15f
            setSingleLine(true)
            setPadding(dp(12), 0, dp(12), 0)
            setBackgroundColor(Color.rgb(15, 27, 47))
        }
        root.addView(prompt, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) })
        root.addView(actionButton("SEND MESSAGE") {
            val text = prompt.text.toString().trim()
            if (text.isNotEmpty()) { prompt.setText(""); askAI(text) }
        }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(8) })

        root.addView(actionButton("OPEN PHONE SECURITY SETTINGS") {
            try {
                startActivity(android.content.Intent(android.provider.Settings.ACTION_SECURITY_SETTINGS))
            } catch (_: Exception) {
                say("Boss, phone ki Settings mein Security ya Screen Lock search kar lo.")
            }
        }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(8) })

        root.addView(actionButton("ENABLE ADVANCED PHONE CONTROL") {
            say("Boss, Accessibility settings khol rahi hoon. Sophia service ko aapko khud enable karna hoga.")
            try { startActivity(android.content.Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            catch (_: Exception) { say("Boss, Settings mein Accessibility search kar lo.") }
        }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(8) })

        root.addView(actionButton("ENABLE INCOMING CALL ANNOUNCEMENTS") {
            if (SophiaNotificationListenerService.isNotificationAccessEnabled(this)) {
                say("Boss, incoming call announcements already enabled hain.")
            } else {
                say("Boss, notification access settings khol rahi hoon. Sophia Incoming Call Announcements ko manually allow karna hoga.")
                try { SophiaNotificationListenerService.openNotificationAccessSettings(this) }
                catch (_: Exception) { say("Boss, Settings mein Notification access search karke Sophia ko allow kar dein.") }
            }
        }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(8) })

        val privacyNote = TextView(this).apply {
            text = "Security note: Sophia cannot bypass your PIN, fingerprint or Android lock. Face detection only notices a face; it does not prove who you are. Background camera and always-on wake-word are not included in this starter because Android restricts them and reliable speaker verification needs a dedicated model/service."
            textSize = 11f
            setTextColor(Color.rgb(255, 190, 130))
            setPadding(0, dp(10), 0, dp(6))
        }
        root.addView(privacyNote, match())

        val endpointLabel = TextView(this).apply {
            text = "ONLINE AI BACKEND (HTTPS URL)"
            textSize = 10f
            setTextColor(Color.rgb(112, 153, 184))
            setPadding(0, dp(16), 0, dp(5))
        }
        root.addView(endpointLabel, match())
        endpointInput = EditText(this).apply {
            hint = "https://your-server.example/chat"
            setHintTextColor(Color.rgb(100, 120, 145))
            setTextColor(Color.WHITE)
            textSize = 12f
            setSingleLine(true)
            setPadding(dp(10), 0, dp(10), 0)
            setBackgroundColor(Color.rgb(15, 27, 47))
        }
        root.addView(endpointInput, LinearLayout.LayoutParams(-1, dp(44)))
        val foot = TextView(this).apply {
            text = "Privacy: camera frames are processed on-device for face presence and are not saved. Background camera detection is intentionally paused when this screen is not visible because Android restricts background camera use."
            textSize = 11f
            setTextColor(Color.rgb(132, 153, 178))
            setPadding(0, dp(12), 0, 0)
        }
        root.addView(foot, match())
    }

    private fun actionButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 12f
            setTextColor(Color.rgb(80, 234, 255))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.rgb(10, 28, 47))
                setStroke(dp(1), Color.rgb(38, 190, 225))
                cornerRadius = dp(10).toFloat()
            }
            setOnClickListener { animate().scaleX(.97f).scaleY(.97f).setDuration(70).withEndAction {
                animate().scaleX(1f).scaleY(1f).setDuration(90).start()
            }.start(); action() }
        }

    private fun startCamera() {
        if (cameraEnabled) return
        if (!allPermissionsGranted()) {
            requestPermissions.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
            return
        }
        cameraEnabled = true
        previewView.visibility = View.GONE
        setStatus("CAMERA ACTIVE · FACE PRESENCE ONLY (NO PREVIEW)")
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                cameraProvider = provider
                val options = FaceDetectorOptions.Builder()
                    .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                    .build()
                val detector = FaceDetection.getClient(options)
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(cameraExecutor) { proxy ->
                    val mediaImage = proxy.image
                    if (mediaImage == null) { proxy.close(); return@setAnalyzer }
                    val image = InputImage.fromMediaImage(mediaImage, proxy.imageInfo.rotationDegrees)
                    detector.process(image)
                        .addOnSuccessListener { faces ->
                            runOnUiThread {
                                if (faces.isNotEmpty()) onFaceDetected() else {
                                    if (facePresent) lastSeenAt = System.currentTimeMillis()
                                    facePresent = false
                                    avatar.detected = false
                                }
                            }
                        }
                        .addOnCompleteListener { proxy.close() }
                }
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
            } catch (e: Exception) {
                cameraEnabled = false
                setStatus("Camera start nahi hua: ${e.message ?: "unknown error"}")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun onFaceDetected() {
        val now = System.currentTimeMillis()
        val returned = !facePresent && lastSeenAt > 0L && now - lastSeenAt > 15_000L
        facePresent = true
        avatar.detected = true
        if (autoGreetingToggle.isChecked && now - lastGreetingAt > cooldownMs &&
            (!returned || now - lastGreetingAt > cooldownMs)) {
            lastGreetingAt = now
            val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
            val greeting = when {
                returned -> "Boss, wapas aa gaye! ❤️ Aaj badi der laga di. Kahan busy the?"
                hour in 5..11 -> "Good morning, Boss! ☀️ Uth gaye? Aaj ka din kaisa shuru ho raha hai?"
                hour in 12..16 -> "Hello Boss! ❤️ Aaj kaise ho? Kuch khaya ya kaam mein busy ho?"
                hour in 17..22 -> "Hello Boss, aa gaye aap! 😄 Aaj kya kar rahe the? Batao na."
                else -> "Boss, raat ho gayi hai. ❤️ Kaise ho? Thodi der baat karte hain, phir aaram bhi kar lena."
            }
            say(greeting)
        }
    }

    private fun stopCamera() {
        cameraEnabled = false
        facePresent = false
        cameraProvider?.unbindAll()
        previewView.visibility = View.GONE
        avatar.detected = false
        setStatus("SYSTEM STANDBY · CAMERA OFF")
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("Is device par speech recognition available nahi hai. Message type karke bhej sakte ho.")
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }
        try {
            if (speechRecognizer == null) speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { setStatus("LISTENING · BOLO BOSS…") }
                override fun onBeginningOfSpeech() { avatar.listening = true }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { avatar.listening = false; setStatus("THINKING…") }
                override fun onError(error: Int) { avatar.listening = false; setStatus("VOICE INPUT READY"); }
                override fun onResults(results: Bundle?) {
                    avatar.listening = false
                    val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (heard.isNotBlank()) { lastHeard = heard; askAI(heard) }
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = android.content.Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Sophia se baat karo, Boss")
            }
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) { setStatus("Voice input start nahi hua.") }
    }

    private fun askAI(message: String) {
        if (handlePhoneCommand(message)) return
        rememberTurn("user", message)
        setStatus("ONLINE AI · CONNECTING…")
        transcript.text = "You: $message\n\nSophia: Soch rahi hoon, Boss… ❤️"
        val endpoint = endpointInput.text.toString().trim()
        if (endpoint.isBlank() || !endpoint.startsWith("https://")) {
            val response = localFallback(message)
            transcript.text = "You: $message\n\nSophia: $response\n\n(Online AI backend set nahi hai. HTTPS endpoint add karo.)"
            rememberTurn("assistant", response)
            say(response)
            return
        }
        Thread {
            var answer: String? = null
            var error: String? = null
            try {
                val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 8000
                    readTimeout = 12000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                val payload = JSONObject()
                    .put("message", message)
                    .put("language", "hi-IN")
                    .put("client_id", clientId)
                    .put("history", JSONArray().apply {
                        synchronized(memory) {
                            memory.dropLast(1).takeLast(12).forEach { (role, content) ->
                                put(JSONObject().put("role", role).put("content", content))
                            }
                        }
                    })
                conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val body = (if (code in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (code in 200..299) {
                    answer = JSONObject(body).optString("reply", "").takeIf { it.isNotBlank() }
                    if (answer.isNullOrBlank()) error = "Backend response mein 'reply' field nahi mila."
                } else error = "AI server HTTP $code"
                conn.disconnect()
            } catch (e: Exception) { error = e.message ?: "Network error" }
            runOnUiThread {
                if (answer != null) {
                    transcript.text = "You: $message\n\nSophia: $answer"
                    rememberTurn("assistant", answer!!)
                    setStatus("ONLINE · RESPONSE READY")
                    say(answer!!)
                } else {
                    val fallback = "Boss, AI server se connect nahi ho paaya. Internet aur backend URL check kar lo."
                    transcript.text = "You: $message\n\nSophia: $fallback\n\nDetail: ${error ?: "unknown"}"
                    setStatus("AI BACKEND NOT CONNECTED")
                    say(fallback)
                }
            }
        }.start()
    }

    /** Handles only explicit user-issued commands locally; AI text is never executed as a command. */
    private fun handlePhoneCommand(raw: String): Boolean {
        val m = raw.trim().lowercase(Locale.ROOT)
        fun done(message: String): Boolean { transcript.text = "You: $raw\n\nSophia: $message"; say(message); return true }
        val appPackages = mapOf(
            "instagram" to "com.instagram.android", "youtube" to "com.google.android.youtube",
            "whatsapp" to "com.whatsapp", "facebook" to "com.facebook.katana",
            "chrome" to "com.android.chrome", "gmail" to "com.google.android.gm",
            "telegram" to "org.telegram.messenger", "spotify" to "com.spotify.music",
            "settings" to "com.android.settings", "camera" to "com.android.camera2",
            "play store" to "com.android.vending", "phone" to "com.google.android.dialer",
            "messages" to "com.google.android.apps.messaging"
        )
        val openName = Regex("^(?:sophia\\s+)?(?:open|kholo|khol do|chalao|launch)\\s+(.+)$").find(m)?.groupValues?.get(1)?.trim()
        if (openName != null) {
            val key = appPackages.keys.firstOrNull { openName == it || openName.contains(it) }
            if (key != null) {
                val launch = packageManager.getLaunchIntentForPackage(appPackages[key]!!)
                if (launch != null) { startActivity(launch.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)); return done("Boss, $key khol diya. ❤️") }
                if (key == "camera") {
                    return try { startActivity(android.content.Intent("android.media.action.IMAGE_CAPTURE")); done("Boss, camera kholne ki koshish ki.") }
                    catch (_: Exception) { done("Boss, is device par camera app nahi mil rahi.") }
                }
                return done("Boss, $key installed nahi hai ya launch nahi ho pa raha. Play Store se check kar sakte hain.")
            }
            return done("Boss, abhi main Instagram, YouTube, WhatsApp, Facebook, Chrome, Gmail, Telegram, Spotify, Settings, Camera, Phone, Messages aur Play Store jaise mapped apps khol sakti hoon.")
        }
        if (m.contains("accessibility") || m.contains("advanced phone control") || m == "enable phone control") {
            startActivity(android.content.Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return done("Boss, Accessibility settings khol di hain. Sophia Phone Control ko aapko manually enable karna hoga.")
        }
        if (m == "back" || m.contains("go back") || m.contains("peeche jao")) {
            sendAccessibilityCommand("BACK"); return done("Boss, back command bhej di. Accessibility service enabled honi chahiye.")
        }
        if (m == "home" || m.contains("home screen") || m.contains("ghar wali screen")) {
            sendAccessibilityCommand("HOME"); return done("Boss, Home command bhej di. Accessibility service enabled honi chahiye.")
        }
        if (m.contains("scroll down") || m.contains("neeche scroll")) {
            sendAccessibilityCommand("SCROLL_DOWN"); return done("Boss, scroll down command bhej di.")
        }
        if (m.contains("scroll up") || m.contains("upar scroll")) {
            sendAccessibilityCommand("SCROLL_UP"); return done("Boss, scroll up command bhej di.")
        }
        val tapText = Regex("^(?:tap|click|dabao|select)\\s+(.+)$").find(m)?.groupValues?.get(1)?.trim()
        if (tapText != null) {
            sendAccessibilityCommand("TAP_TEXT", tapText)
            return done("Boss, screen par ‘$tapText’ text ko tap karne ki request bhej di. Agar action sensitive hua to system confirmation ki zaroorat ho sakti hai.")
        }
        val dialNumber = Regex("^(?:sophia\\s+)?(?:call|phone|dial|call karo)\\s+([+0-9][+0-9() -]{5,})$").find(raw.trim())?.groupValues?.get(1)?.trim()
        if (dialNumber != null) {
            return try { startActivity(android.content.Intent(android.content.Intent.ACTION_DIAL, android.net.Uri.parse("tel:" + dialNumber.replace(" ", "")))); done("Boss, number dialer mein khol diya. Call karne ke liye confirm kar lena.") }
            catch (_: Exception) { done("Boss, dialer open nahi ho paaya.") }
        }
        val callName = Regex("^(?:sophia\\s+)?(?:call|phone|call karo)\\s+([a-z][a-z .'-]{1,40})$", RegexOption.IGNORE_CASE).find(raw.trim())?.groupValues?.get(1)?.trim()
        if (callName != null && callName !in listOf("me", "kar do", "karo")) {
            return try { startActivity(android.content.Intent(android.content.Intent.ACTION_PICK, android.provider.ContactsContract.Contacts.CONTENT_URI)); done("Boss, contacts khol diye. $callName ko select kar lo, phir dialer mein call confirm kar sakte ho.") }
            catch (_: Exception) { done("Boss, Contacts app open nahi ho paayi.") }
        }
        val sms = Regex("^(?:message|sms|text)\\s+([+0-9][+0-9() -]{5,})\\s+(.+)$", RegexOption.IGNORE_CASE).find(raw.trim())
        if (sms != null) {
            val number = sms.groupValues[1].replace(" ", "")
            val body = sms.groupValues[2]
            return try { startActivity(android.content.Intent(android.content.Intent.ACTION_SENDTO, android.net.Uri.parse("smsto:$number")).putExtra("sms_body", body)); done("Boss, message draft tayyar hai. Bhejne se pehle check kar lena.") }
            catch (_: Exception) { done("Boss, messaging app open nahi ho paayi.") }
        }
        val uninstallName = Regex("^(?:uninstall|delete app|remove app)\\s+(.+)$").find(m)?.groupValues?.get(1)?.trim()
        if (uninstallName != null) {
            val key = appPackages.keys.firstOrNull { uninstallName == it || uninstallName.contains(it) }
            if (key == null) return done("Boss, is app ka uninstall shortcut mapped nahi hai. Settings → Apps se uninstall kar sakte ho.")
            android.app.AlertDialog.Builder(this)
                .setTitle("Uninstall $key?")
                .setMessage("Boss, Android ka system uninstall screen khulega. App ko remove karne se pehle wahan confirm karna hoga.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Continue") { _, _ ->
                    try { startActivity(android.content.Intent(android.content.Intent.ACTION_DELETE, android.net.Uri.parse("package:${appPackages[key]}"))) }
                    catch (_: Exception) { say("Boss, Android uninstall screen open nahi ho paayi.") }
                }.show()
            return done("Boss, pehle confirmation le rahi hoon. ❤️")
        }
        val installName = Regex("^(?:install|download)\\s+(.+)$").find(m)?.groupValues?.get(1)?.trim()
        if (installName != null) {
            return try {
                val uri = android.net.Uri.parse("market://search?q=" + android.net.Uri.encode(installName))
                startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, uri)); done("Boss, Play Store mein $installName search kar diya. Install aapko confirm karna hoga.")
            } catch (_: Exception) {
                startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://play.google.com/store/search?q=" + android.net.Uri.encode(installName) + "&c=apps")))
                done("Boss, Play Store search khol di. Install aapko confirm karna hoga.")
            }
        }
        return false
    }

    private fun sendAccessibilityCommand(command: String, text: String? = null) {
        val intent = android.content.Intent("com.arking.jarvis2070.ACCESSIBILITY_COMMAND")
            .setPackage(packageName).putExtra("command", command)
        if (text != null) intent.putExtra("text", text)
        sendBroadcast(intent)
    }

    private fun loadMemory() {
        val raw = memoryPrefs.getString("turns", "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val item = arr.getJSONObject(i)
                memory.add(item.optString("role") to item.optString("content"))
            }
        } catch (_: Exception) { memory.clear() }
    }

    private fun rememberTurn(role: String, content: String) {
        synchronized(memory) {
            memory.add(role to content.take(1200))
            while (memory.size > 20) memory.removeAt(0)
            val arr = JSONArray()
            memory.forEach { (r, c) -> arr.put(JSONObject().put("role", r).put("content", c)) }
            memoryPrefs.edit().putString("turns", arr.toString()).apply()
        }
    }

    private fun maybeNightReminder() {
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        if (hour >= 23 || hour < 5) {
            val day = java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).format(java.util.Date())
            if (memoryPrefs.getString("night_reminder_day", "") != day) {
                memoryPrefs.edit().putString("night_reminder_day", day).apply()
                window.decorView.postDelayed({
                    if (!isFinishing) say("Boss, kaafi raat ho gayi hai. ❤️ Agar neend aa rahi hai toh phone side mein rakhkar aaram kar lo.")
                }, 1200L)
            }
        }
    }

    private fun localFallback(message: String): String {
        val m = message.lowercase(Locale.ROOT)
        return when {
            "hello" in m || "hi" in m || "hey" in m || "namaste" in m ->
                "Hello Boss! ❤️ Main Sophia hoon. Online AI ke liye apna HTTPS backend connect kar do, phir hum aur natural baat karenge."
            "time" in m || "samay" in m || "baje" in m ->
                "Abhi ${java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(java.util.Date())} ho rahe hain."
            "date" in m || "tarikh" in m || "tareekh" in m ->
                "Aaj ${java.text.SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(java.util.Date())} hai."
            else -> "Main sun rahi hoon, Boss. ❤️ Full online conversation ke liye HTTPS AI backend URL add karo."
        }
    }

    private fun say(text: String) {
        if (!ttsReady) { transcript.text = transcript.text.toString() + "\n\n(Voice engine is loading.)"; return }
        avatar.speaking = true
        setStatus("SOPHIA SPEAKING")
        tts.setSpeechRate(0.94f)
        tts.setPitch(1.12f)
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sophia-${System.currentTimeMillis()}")
        avatar.postDelayed({ avatar.speaking = false; setStatus(if (cameraEnabled) "CAMERA ACTIVE · PRESENCE DETECTION ON" else "SYSTEM READY") }, 3000L)
    }

    override fun onInit(statusCode: Int) {
        ttsReady = statusCode == TextToSpeech.SUCCESS
        if (ttsReady) {
            val result = tts.setLanguage(Locale("hi", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.language = Locale.US
            }
            val voices = tts.voices?.filter { it.locale.language == "hi" || it.locale.language == "en" }
            val preferred = voices?.firstOrNull { it.name.contains("female", true) }
            if (preferred != null) tts.voice = preferred
        }
    }

    private fun setStatus(text: String) { if (::status.isInitialized) status.text = text }

    private fun allPermissionsGranted() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    override fun onResume() {
        super.onResume()
        // Camera is bound to this Activity lifecycle; Android stops camera access when it is no longer visible.
        if (::cameraToggle.isInitialized && cameraToggle.isChecked && !cameraEnabled &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        }
    }

    override fun onPause() {
        // Intentionally pause camera when app is not in foreground. No covert background camera access.
        if (::cameraToggle.isInitialized && isFinishing) stopCamera()
        super.onPause()
    }

    override fun onDestroy() {
        stopCamera()
        speechRecognizer?.destroy()
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        cameraExecutor.shutdown()
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun match() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
}

class HoloAvatarView(context: Context) : View(context) {
    var speaking = false
        set(value) { field = value; invalidate() }
    var listening = false
        set(value) { field = value; invalidate() }
    var detected = false
        set(value) { field = value; invalidate() }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cyan = Color.rgb(58, 231, 255)
    private val violet = Color.rgb(140, 95, 255)
    private var tick = 0
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private val pulse = object : Runnable {
        override fun run() { tick++; invalidate(); handler.postDelayed(this, 45L) }
    }
    init { handler.post(pulse) }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val phase = tick * 0.045f
        val pulseScale = if (speaking || listening || detected) 1.0f + 0.035f * sin(phase * 2) else 1.0f
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.5f
        paint.color = cyan
        paint.alpha = 180
        for (i in 0..3) {
            val r = (48f + i * 17f) * pulseScale
            canvas.drawCircle(cx, cy, r, paint)
        }
        paint.color = violet
        paint.strokeWidth = 3f
        val rect = RectF(cx - 85, cy - 85, cx + 85, cy + 85)
        canvas.drawArc(rect, tick * 2f % 360f, 110f, false, paint)
        canvas.drawArc(rect, (180f + tick * -1.5f) % 360f, 70f, false, paint)

        // Minimal holographic female face silhouette, drawn locally with Canvas.
        paint.style = Paint.Style.FILL
        paint.color = Color.argb(35, 58, 231, 255)
        canvas.drawOval(RectF(cx - 49, cy - 62, cx + 49, cy + 66), paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2.2f
        paint.color = if (detected) Color.rgb(255, 105, 190) else cyan
        val face = Path().apply {
            moveTo(cx - 37, cy - 26)
            quadTo(cx - 50, cy + 14, cx - 22, cy + 45)
            quadTo(cx, cy + 66, cx + 22, cy + 45)
            quadTo(cx + 50, cy + 14, cx + 37, cy - 26)
            quadTo(cx, cy - 80, cx - 37, cy - 26)
        }
        canvas.drawPath(face, paint)
        paint.strokeWidth = 3f
        canvas.drawLine(cx - 24, cy - 5, cx - 9, cy - 5, paint)
        canvas.drawLine(cx + 9, cy - 5, cx + 24, cy - 5, paint)
        paint.strokeWidth = 1.6f
        canvas.drawLine(cx - 5, cy + 13, cx + 5, cy + 13, paint)
        canvas.drawArc(RectF(cx - 13, cy + 20, cx + 13, cy + 35), 10f, 160f, false, paint)
        paint.style = Paint.Style.FILL
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = 10f
        paint.color = cyan
        val label = when {
            listening -> "LISTENING"
            speaking -> "SPEAKING"
            detected -> "PRESENCE DETECTED"
            else -> "HOLOGRAM ONLINE"
        }
        canvas.drawText(label, cx, height - 12f, paint)
        // orbiting particles
        for (i in 0 until 16) {
            val a = phase + i * (Math.PI * 2 / 16)
            val r = 108f + 5f * sin(phase + i)
            paint.color = if (i % 3 == 0) violet else cyan
            canvas.drawCircle(cx + cos(a).toFloat() * r, cy + sin(a).toFloat() * r, if (i % 4 == 0) 3.2f else 1.8f, paint)
        }
        paint.alpha = 255
    }
}
