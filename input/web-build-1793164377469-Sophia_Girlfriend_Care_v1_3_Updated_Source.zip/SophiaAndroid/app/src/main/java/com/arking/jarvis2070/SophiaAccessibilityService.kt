package com.arking.jarvis2070

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Optional, user-enabled UI helper. It only responds to explicit commands sent by Sophia's app.
 * It does not read screen contents into the cloud, capture passwords, or auto-confirm dialogs.
 */
class SophiaAccessibilityService : AccessibilityService() {
    private val commandReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val command = intent?.getStringExtra("command") ?: return
            when (command) {
                "BACK" -> performGlobalAction(GLOBAL_ACTION_BACK)
                "HOME" -> performGlobalAction(GLOBAL_ACTION_HOME)
                "SCROLL_DOWN" -> scrollActiveWindow(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
                "SCROLL_UP" -> scrollActiveWindow(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
                "TAP_TEXT" -> intent.getStringExtra("text")?.let { tapVisibleText(it) }
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        val filter = IntentFilter("com.arking.jarvis2070.ACCESSIBILITY_COMMAND")
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            registerReceiver(commandReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(commandReceiver, filter)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally no background screen scraping. Commands are handled only on user request.
    }

    override fun onInterrupt() { }

    override fun onDestroy() {
        try { unregisterReceiver(commandReceiver) } catch (_: Exception) { }
        super.onDestroy()
    }

    private fun scrollActiveWindow(action: Int) {
        val root = rootInActiveWindow ?: return
        try { scrollFirstScrollable(root, action) } finally { root.recycle() }
    }

    private fun scrollFirstScrollable(node: AccessibilityNodeInfo, action: Int): Boolean {
        if (node.isScrollable && node.performAction(action)) return true
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val done = scrollFirstScrollable(child, action)
            child.recycle()
            if (done) return true
        }
        return false
    }

    private fun tapVisibleText(requested: String) {
        val root = rootInActiveWindow ?: return
        try {
            val target = findTextNode(root, requested.trim()) ?: return
            var clickable: AccessibilityNodeInfo? = target
            while (clickable != null && !clickable.isClickable) {
                val parent = clickable.parent
                if (clickable !== target) clickable.recycle()
                clickable = parent
            }
            clickable?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            if (clickable !== target) clickable?.recycle()
            target.recycle()
        } finally { root.recycle() }
    }

    private fun findTextNode(node: AccessibilityNodeInfo, requested: String): AccessibilityNodeInfo? {
        val text = node.text?.toString()?.trim()
        val description = node.contentDescription?.toString()?.trim()
        if (node.isVisibleToUser && (text.equals(requested, true) || description.equals(requested, true))) {
            return AccessibilityNodeInfo.obtain(node)
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findTextNode(child, requested)
            child.recycle()
            if (found != null) return found
        }
        return null
    }
}
