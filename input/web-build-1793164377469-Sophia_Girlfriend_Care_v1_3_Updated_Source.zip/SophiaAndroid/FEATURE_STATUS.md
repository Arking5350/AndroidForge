# Sophia feature status (source v1.3)

| Feature | Status in this source revision |
|---|---|
| Girlfriend-style playful/caring personality and time-based greeting | Basic implementation included; online conversation needs backend |
| Online AI conversation | Requires HTTPS PHP backend and provider configuration |
| Local recent conversation memory | Included (last 20 turns stored locally; recent context sent to backend) |
| Night reminder | On app open, once per date after 11 PM / before 5 AM |
| Incoming-call announcement | New optional NotificationListenerService announces likely incoming-call notifications after user grants Notification Access; device/app notification formats vary |
| Face presence detection | Included only while app is open and camera is enabled; face presence is not identity verification |
| Food/activity recognition | Not implemented; face presence detection cannot tell whether the user is eating or what they are doing |
| Launch mapped apps by explicit command | Implemented for common apps; package names vary by device |
| Call a number | Opens Android dialer; user confirms call |
| Call a contact name | Opens Contacts picker; user selects contact and confirms call |
| SMS a number | Opens message draft; user reviews and sends |
| Install app | Opens Play Store search; user confirms install |
| Uninstall mapped app | In-app confirmation then Android system uninstall screen; user confirms |
| Accessibility navigation | Optional service supports Back, Home, scroll and exact visible-text tap after user manually enables it |
| Accessibility sensitive actions | Not auto-confirmed; target apps/system dialogs may block automation |
| Camera from Home Screen / background | Not implemented; Android restrictions apply |
| “Sophia” always-on wake word | Not implemented |
| Voice command to answer/reject incoming calls | Not implemented; announcement asks what the user wants, but this source does not answer/reject calls |
| Owner-only voice verification | Not implemented; speech recognition is not speaker verification |
| Natural neural female voice | Not included; device TTS used |
| Secure lock/unlock | Opens Android Security Settings; does not unlock or bypass lock |

This is source code only. It has not been built or tested as an APK in this environment.
