# Jarvis 2070 — Native Android Starter

A native Kotlin Android Studio starter project with:
- Animated hologram-style avatar (Canvas, no external assets)
- CameraX front-camera preview
- On-device ML Kit face-presence detection (frames are not saved)
- Greeting when presence is detected, with a 90-second cooldown
- Hindi/Hinglish speech input via Android SpeechRecognizer
- Text-to-speech with a higher pitch and a preference for a voice whose name includes "female" when the device has one
- Optional HTTPS AI backend
- Explicit camera toggle and visible status text

## Important limitations
- This is a starter project, not a verified compiled APK.
- Camera presence detection is active only while the Activity is visible. Android restricts camera access in background; this app intentionally does not attempt covert/background camera use.
- The "AI backend" field expects an HTTPS endpoint accepting POST JSON like `{"message":"Hello","language":"hi-IN"}` and returning JSON like `{"reply":"Namaste!"}`. Implement the endpoint on your own server. Do not put provider API keys in the Android app.
- Without a configured backend, only simple local fallback replies (greetings/time/date) work. Online conversational AI is not bundled.
- Female voice availability and quality depend on installed Android TTS voices. This project cannot guarantee a natural human-like voice on every device.
- Face presence is not identity verification. It can detect a face but does not prove that it is the owner.
- The app does not unlock or bypass the Android lock screen.
- Test permissions and lifecycle behavior on a real device.

## Build APK in Android Studio
1. Install Android Studio (current stable) and a JDK 17.
2. Extract this ZIP and open the `Jarvis2070Android` folder in Android Studio.
3. Allow Gradle sync and dependency downloads.
4. Connect an Android phone with USB debugging enabled, or use an emulator with camera support.
5. Press Run to install the debug app.
6. To build an APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
7. Android Studio shows the generated APK path in its build notification (usually `app/build/outputs/apk/debug/app-debug.apk`).

## Connect an online AI backend
Create an HTTPS endpoint on your own server. It should:
- Accept `POST` JSON with `message` and `language`.
- Authenticate requests and apply rate limits.
- Call your AI provider server-side (never expose API keys in this app).
- Return JSON: `{"reply":"...response text..."}`.
- Use TLS/HTTPS and validate inputs.

## Privacy
Camera frames are processed for face detection and are not written to disk by this starter. The preview and camera status are visible. Turn off the camera toggle to stop detection. Avoid using face detection to infer sensitive traits.
